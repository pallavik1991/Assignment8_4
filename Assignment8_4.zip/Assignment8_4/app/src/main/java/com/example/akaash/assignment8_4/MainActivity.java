package com.example.akaash.assignment8_4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;

public class MainActivity extends AppCompatActivity {

    private GridView grid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String[] title={"GingerBread","Honeycomb","IceCream","JellyBean","KitKat","Lollipop"};
        Integer[] imgid={R.drawable.ginger,R.drawable.honeycomb,
                         R.drawable.icecream,R.drawable.jellybean,
                         R.drawable.kitkat,R.drawable.lollipop
        };
        grid=(GridView)findViewById(R.id.grid);

        CustomGrid customGrid=new CustomGrid(MainActivity.this,title,imgid);
        grid.setAdapter(customGrid);


    }
}
