package com.example.akaash.assignment8_4;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by AKAASH on 07-11-2017.
 */

public class CustomGrid extends ArrayAdapter<String>
{

    private final Activity context;
    private final String[] title;
    private final Integer[] imgid;

    public CustomGrid(Activity context, String[] title,Integer[] imgid) {
        super(context, R.layout.custom_grid,title);

        this.context=context;
        this.title=title;
        this.imgid=imgid;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent)
    {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.custom_grid, null,true);

        TextView txtTitle = (TextView) rowView.findViewById(R.id.txt);
        ImageView imageView = (ImageView) rowView.findViewById(R.id.img);


        txtTitle.setText(title[position]);
        imageView.setImageResource(imgid[position]);

        return rowView;
    }
}
